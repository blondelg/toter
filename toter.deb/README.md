# toter
Run selected text into a terminal
