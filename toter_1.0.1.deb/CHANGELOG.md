# Changelog

## [1.0.1] - 2022-05-22
### Added
- Command to generate a ~/.toter.conf file allowing to customize toter's behaviour
- Add a config *close_confirmation* that enable or disable automatic closing of openned terminal

## [1.0.0] - 2022-05-22
### Added
- Init project